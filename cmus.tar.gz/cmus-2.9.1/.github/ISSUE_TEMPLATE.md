<!-- Please fill the following if you have found an issue, delete if otherwise. -->
---

1) `uname -a`:
```
(paste output here)
```

2) `cmus --version`:
```
(paste output here)
```

3) `cmus --plugins`:
```
(paste output here)
```
